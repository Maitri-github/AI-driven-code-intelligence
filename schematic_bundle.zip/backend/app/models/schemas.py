from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class RepoAnalyzeRequest(BaseModel):
    repo_url: str = Field(..., description="Public or private GitHub repository URL (e.g. https://github.com/owner/repo)")
    github_token: Optional[str] = Field(None, description="Optional GitHub Personal Access Token for private repositories or rate limit relief")
    branch: Optional[str] = Field(None, description="Optional branch or tag to analyze (defaults to repo default branch)")
    file_cap: Optional[int] = Field(40, description="Maximum number of matched files to analyze")
    use_cache: bool = Field(True, description="Whether to leverage the SQLite analysis cache")


class FileExplanation(BaseModel):
    file_path: str
    content_hash: str
    language: str
    overview: str
    key_components: List[str]
    flow: str
    notable_risks: str
    cache_hit: bool = False
    line_count: int = 0
    raw_source: Optional[str] = None


class APIRefParameter(BaseModel):
    name: str
    type: Optional[str] = None
    description: Optional[str] = None
    required: bool = True
    default: Optional[str] = None


class APIRefItem(BaseModel):
    file_path: str
    name: str
    type: str = Field("function", description="function, class, method, or route")
    signature: str
    purpose: str
    parameters: List[APIRefParameter] = []
    returns: Optional[str] = None
    errors: List[str] = []
    line_number: Optional[int] = None
    http_method: Optional[str] = None
    http_path: Optional[str] = None


class DependencyEdge(BaseModel):
    source_file: str
    target_module: str
    import_names: List[str] = []
    is_internal: bool = False


class SubsystemCluster(BaseModel):
    name: str
    description: str
    files: List[str]


class ArchitectureResult(BaseModel):
    mermaid_diagram: str
    raw_mermaid: str
    subsystems: List[SubsystemCluster] = []
    dependencies: List[DependencyEdge] = []
    total_modules: int = 0
    total_dependencies: int = 0


class RepoAnalysisResult(BaseModel):
    repo_id: str
    repo_url: str
    branch: Optional[str] = "main"
    total_files_found: int
    total_files_analyzed: int
    is_capped: bool
    cache_hits: int
    cache_misses: int
    explanations: List[FileExplanation]
    architecture: ArchitectureResult
    api_docs: List[APIRefItem]
    created_at: str
    duration_seconds: float
    watsonx_model_used: str
    is_mock_fallback: bool = False


class AnalysisProgress(BaseModel):
    task_id: str
    repo_url: str
    status: str  # pending, cloning, scanning, analyzing, architecture, docs, completed, failed
    current_file: Optional[str] = None
    current_index: int = 0
    total_files: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    percentage: int = 0
    message: str = ""
    error: Optional[str] = None
    result: Optional[RepoAnalysisResult] = None


class PRDiffSimulateRequest(BaseModel):
    repo_url: str
    pr_title: str = "Example PR"
    pr_number: Optional[int] = 1
    base_branch: str = "main"
    head_branch: str = "feature/update"
    pr_diff: str = Field(..., description="Unified git diff or changed code description")
    github_token: Optional[str] = None
    post_comment: bool = False


class PRAnalysisResponse(BaseModel):
    summary: str
    architecture_impact: str
    docs_impact: str
    needs_diagram_update: bool
    needs_docs_update: bool
    changed_files: List[str]
    comment_markdown: str
    posted_to_github: bool = False
    error: Optional[str] = None


class WatsonxStatusResponse(BaseModel):
    configured: bool
    api_key_set: bool
    project_id_set: bool
    url: str
    model_id: str
    fallback_model_id: str
    connected: bool
    active_model: Optional[str] = None
    message: str


class WatsonxTestRequest(BaseModel):
    api_key: Optional[str] = None
    project_id: Optional[str] = None
    url: Optional[str] = None
    model_id: Optional[str] = None


class CacheStatsResponse(BaseModel):
    total_cached_files: int
    total_cached_repos: int
    db_size_bytes: int
    db_path: str
