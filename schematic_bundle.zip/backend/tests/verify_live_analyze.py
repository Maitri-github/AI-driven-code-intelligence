import sys
import time
import httpx

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

client = httpx.Client(base_url="http://localhost:8000", timeout=60.0)

print("Testing repo analysis API on bottlepy/bottle...")
r = client.post("/api/analyze", json={
    "repo_url": "https://github.com/bottlepy/bottle",
    "file_cap": 15,
    "use_cache": True
})
print("Analyze response:", r.status_code, r.json())
task_id = r.json()["task_id"]

for _ in range(30):
    time.sleep(1)
    prog_resp = client.get(f"/api/progress/{task_id}")
    prog = prog_resp.json()
    print(f"Status: {prog['status']}, %: {prog['percentage']}, Msg: {prog['message']}")
    if prog["status"] in ("completed", "failed"):
        break

if prog["status"] == "completed":
    res = prog["result"]
    print("\nSUCCESS! Analysis Results:")
    print(f"- Total Analyzed: {res['total_files_analyzed']}")
    print(f"- Subsystems: {len(res['architecture']['subsystems'])}")
    print(f"- API Docs: {len(res['api_docs'])}")
    print(f"- Duration: {res['duration_seconds']}s")
else:
    print(f"\nTask failed or timed out: {prog.get('error')}")
