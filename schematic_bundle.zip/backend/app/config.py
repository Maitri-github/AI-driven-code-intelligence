import os
from pathlib import Path
from typing import List, Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Base directory for the project
BASE_DIR = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = BASE_DIR / "data"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DB_PATH = CACHE_DIR / "schematic_cache.db"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )

    # IBM watsonx.ai Credentials
    watsonx_api_key: Optional[str] = Field(default=None, alias="WATSONX_API_KEY")
    watsonx_project_id: Optional[str] = Field(default=None, alias="WATSONX_PROJECT_ID")
    watsonx_url: str = Field(default="https://us-south.ml.cloud.ibm.com", alias="WATSONX_URL")
    
    # Models
    watsonx_model_id: str = Field(default="ibm/granite-8b-code-instruct", alias="WATSONX_MODEL_ID")
    watsonx_fallback_model_id: str = Field(default="ibm/granite-3-8b-instruct", alias="WATSONX_FALLBACK_MODEL_ID")
    watsonx_api_version: str = Field(default="2025-02-06", alias="WATSONX_API_VERSION")

    # Scope & Limits
    default_file_cap: int = Field(default=40, alias="DEFAULT_FILE_CAP")
    supported_extensions: str = Field(
        default=".py,.js,.ts,.tsx,.jsx,.java,.go,.rb",
        alias="SUPPORTED_EXTENSIONS"
    )

    # Server configuration
    host: str = Field(default="0.0.0.0", alias="HOST")
    port: int = Field(default=8000, alias="PORT")
    github_webhook_secret: Optional[str] = Field(default=None, alias="GITHUB_WEBHOOK_SECRET")

    # Cache Path
    cache_db_path: Path = CACHE_DB_PATH

    @property
    def extension_list(self) -> List[str]:
        return [ext.strip().lower() for ext in self.supported_extensions.split(",") if ext.strip()]

    @property
    def has_watsonx_credentials(self) -> bool:
        return bool(self.watsonx_api_key and self.watsonx_project_id)


settings = Settings()
