import logging
from fastapi import APIRouter
from app.config import settings
from app.models.schemas import WatsonxStatusResponse, WatsonxTestRequest
from app.services.watsonx_client import watsonx_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/config", tags=["Configuration"])


@router.get("/status", response_model=WatsonxStatusResponse)
async def get_watsonx_status():
    """Check IBM watsonx.ai configuration status."""
    is_conf = watsonx_client.is_configured()
    msg = (
        "IBM watsonx.ai credentials detected and ready."
        if is_conf else
        "IBM watsonx.ai credentials not configured. Running in Mock/Heuristic Mode. Add WATSONX_API_KEY and WATSONX_PROJECT_ID to enable live Granite models."
    )
    return WatsonxStatusResponse(
        configured=is_conf,
        api_key_set=bool(settings.watsonx_api_key),
        project_id_set=bool(settings.watsonx_project_id),
        url=settings.watsonx_url,
        model_id=settings.watsonx_model_id,
        fallback_model_id=settings.watsonx_fallback_model_id,
        connected=is_conf,
        active_model=settings.watsonx_model_id if is_conf else "Mock Granite Engine",
        message=msg
    )


@router.post("/test-watsonx")
async def test_watsonx_credentials(request: WatsonxTestRequest):
    """Test connection and authentication to IBM watsonx.ai Granite models."""
    return await watsonx_client.test_connection(
        api_key=request.api_key,
        project_id=request.project_id,
        url=request.url,
        model_id=request.model_id
    )
