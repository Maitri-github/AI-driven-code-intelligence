import pytest
import tempfile
from pathlib import Path
from app.services.cache import CacheService

def test_cache_file_lifecycle():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_file = Path(tmpdir) / "test_cache.db"
        cache = CacheService(db_path=db_file)

        # 1. Miss initially
        miss = cache.get_file_cache("app/test.py", "hash123")
        assert miss is None

        # 2. Save
        cache.save_file_cache(
            file_path="app/test.py",
            content_hash="hash123",
            language="python",
            line_count=45,
            overview="Test module",
            key_components=["Component A"],
            flow="Sequential",
            notable_risks="None",
            api_docs=[{"name": "test_fn", "type": "function", "signature": "def test_fn()"}],
            imports=[{"module": "os", "imported_names": ["os"]}]
        )

        # 3. Hit
        hit = cache.get_file_cache("app/test.py", "hash123")
        assert hit is not None
        assert hit["overview"] == "Test module"
        assert hit["line_count"] == 45
        assert len(hit["key_components"]) == 1
        assert len(hit["api_docs"]) == 1

        # 4. Stats
        stats = cache.get_stats()
        assert stats["total_cached_files"] == 1

        # 5. Clear
        cache.clear()
        stats_cleared = cache.get_stats()
        assert stats_cleared["total_cached_files"] == 0
