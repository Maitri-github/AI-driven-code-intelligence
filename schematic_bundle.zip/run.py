import os
import sys
from pathlib import Path

# Ensure UTF-8 output on Windows consoles
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Add backend directory to sys.path
BASE_DIR = Path(__file__).resolve().parent
BACKEND_DIR = BASE_DIR / "backend"
sys.path.insert(0, str(BACKEND_DIR))

import uvicorn
from app.config import settings

def main():
    print("=" * 70)
    print("  [SCHEMATIC] Repo-Wide Code Intelligence & Documentation Prototype")
    print("  Powered by IBM watsonx.ai Granite Foundation Models")
    print("=" * 70)
    
    if settings.has_watsonx_credentials:
        print("  [AI Engine]  IBM watsonx.ai CONNECTED")
        print(f"  [Model ID]   {settings.watsonx_model_id}")
        print(f"  [Fallback]   {settings.watsonx_fallback_model_id}")
        print(f"  [Region]     {settings.watsonx_url}")
    else:
        print("  [AI Engine]  MOCK / HEURISTIC MODE ACTIVE (No credentials in .env)")
        print("               To connect live Granite models, set in .env:")
        print("               WATSONX_API_KEY=your_key_here")
        print("               WATSONX_PROJECT_ID=your_project_id_here")
    
    print(f"  [Cache DB]   {settings.cache_db_path}")
    print(f"  [Server URL] http://localhost:{settings.port}")
    print("=" * 70)
    print(f"  Starting FastAPI server on http://{settings.host}:{settings.port} ...\n")

    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=False,
        log_level="info"
    )

if __name__ == "__main__":
    main()
