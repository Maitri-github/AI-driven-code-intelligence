import pytest
from app.services.code_parser import code_parser, CodeParser

def test_parse_python_file():
    code = """
import os
from typing import List, Optional
from app.models import User

class UserService:
    \"\"\"Service managing user accounts.\"\"\"
    def __init__(self, db_client):
        self.db = db_client

    def get_user(self, user_id: int) -> Optional[User]:
        return self.db.find(user_id)

async def create_user_handler(name: str, email: str):
    \"\"\"Create a new user entry.\"\"\"
    service = UserService(None)
    return service.get_user(1)
"""
    result = code_parser.parse_file("app/services/user.py", code)
    assert result.language == "python"
    assert result.line_count > 10
    assert len(result.content_hash) == 64
    
    # Check imports
    modules = [imp.module for imp in result.imports]
    assert "os" in modules
    assert "typing" in modules
    assert "app.models" in modules

    # Check classes
    assert len(result.classes) == 1
    assert result.classes[0].name == "UserService"
    assert len(result.classes[0].methods) == 2

    # Check functions
    fn_names = [fn.name for fn in result.functions]
    assert "create_user_handler" in fn_names


def test_parse_javascript_file():
    code = """
import express from 'express';
import { authenticateToken } from '../middleware/auth';
const router = express.Router();

router.get('/api/users', (req, res) => {
    res.json({ users: [] });
});

export const calculateMetric = (a, b) => {
    return a + b;
};
"""
    result = code_parser.parse_file("src/routes/users.js", code)
    assert result.language == "javascript"
    
    # Check imports
    modules = [imp.module for imp in result.imports]
    assert "express" in modules
    assert "../middleware/auth" in modules

    # Check route / function detection
    assert len(result.functions) >= 2
    route_fn = [f for f in result.functions if f.is_route]
    assert len(route_fn) == 1
    assert route_fn[0].http_method == "GET"
    assert route_fn[0].http_path == "/api/users"


def test_parse_go_file():
    code = """
package main

import (
    "fmt"
    "net/http"
)

type Server struct {
    port int
}

func (s *Server) Start() error {
    return nil
}

func HandleHealth(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "OK")
}
"""
    result = code_parser.parse_file("main.go", code)
    assert result.language == "go"
    assert len(result.classes) == 1
    assert result.classes[0].name == "Server"
    assert len(result.functions) >= 2


def test_chunking():
    large_code = "\n".join([f"def func_{i}():\n    return {i}" for i in range(100)])
    chunks = code_parser.chunk_content(large_code, max_chunk_lines=30)
    assert len(chunks) > 1
