const { useState, useEffect, useRef, useMemo } = React;

// Initialize Mermaid
if (window.mermaid) {
  mermaid.initialize({
    startOnLoad: false,
    theme: 'dark',
    securityLevel: 'loose',
    fontFamily: 'Inter, system-ui, sans-serif',
    themeVariables: {
      darkMode: true,
      background: '#0b1120',
      primaryColor: '#1e3a8a',
      primaryTextColor: '#f8fafc',
      primaryBorderColor: '#3b82f6',
      lineColor: '#64748b',
      secondaryColor: '#14532d',
      tertiaryColor: '#1e293b'
    }
  });
}

function App() {
  const [activeTab, setActiveTab] = useState('analyze');
  const [watsonxStatus, setWatsonxStatus] = useState(null);
  const [cacheStats, setCacheStats] = useState(null);
  
  // Analysis Form State
  const [repoUrl, setRepoUrl] = useState('https://github.com/fastapi/fastapi');
  const [branch, setBranch] = useState('');
  const [githubToken, setGithubToken] = useState('');
  const [fileCap, setFileCap] = useState(40);
  const [useCache, setUseCache] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Analysis Task & Result State
  const [currentTaskId, setCurrentTaskId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState(null);

  // Explanation Viewer State
  const [selectedFilePath, setSelectedFilePath] = useState(null);
  const [fileSearchQuery, setFileSearchQuery] = useState('');

  // API Docs Filter State
  const [docSearchQuery, setDocSearchQuery] = useState('');
  const [docTypeFilter, setDocTypeFilter] = useState('all');

  // PR Simulator State
  const [prRepoUrl, setPrRepoUrl] = useState('https://github.com/fastapi/fastapi');
  const [prTitle, setPrTitle] = useState('feat: Add new user profile route and auth dependency');
  const [prNumber, setPrNumber] = useState(142);
  const [prDiff, setPrDiff] = useState(`diff --git a/app/routes/users.py b/app/routes/users.py
new file mode 100644
index 0000000..8a4b2c1
--- /dev/null
+++ b/app/routes/users.py
@@ -0,0 +1,18 @@
+from fastapi import APIRouter, Depends, HTTPException
+from app.services.auth import get_current_user
+from app.models.user import UserProfile
+
+router = APIRouter(prefix="/users", tags=["Users"])
+
+@router.get("/{user_id}/profile", response_model=UserProfile)
+async def get_user_profile(user_id: int, current_user = Depends(get_current_user)):
+    """Fetch user profile with authentication guard."""
+    if user_id != current_user.id and not current_user.is_admin:
+        raise HTTPException(status_code=403, detail="Access denied")
+    return {"id": user_id, "username": current_user.username}`);
+  const [isSimulatingPR, setIsSimulatingPR] = useState(false);
+  const [prAnalysisResult, setPrAnalysisResult] = useState(null);
+  const [webhookEvents, setWebhookEvents] = useState([]);

  // Fetch status on mount
  useEffect(() => {
    fetchWatsonxStatus();
    fetchCacheStats();
    fetchWebhookEvents();
  }, []);

  const fetchWatsonxStatus = async () => {
    try {
      const res = await fetch('/api/config/status');
      const data = await res.json();
      setWatsonxStatus(data);
    } catch (e) {
      console.error('Error fetching watsonx status:', e);
    }
  };

  const fetchCacheStats = async () => {
    try {
      const res = await fetch('/api/cache/stats');
      const data = await res.json();
      setCacheStats(data);
    } catch (e) {
      console.error('Error fetching cache stats:', e);
    }
  };

  const fetchWebhookEvents = async () => {
    try {
      const res = await fetch('/api/webhook/events');
      const data = await res.json();
      setWebhookEvents(data.events || []);
    } catch (e) {
      console.error('Error fetching webhook events:', e);
    }
  };

  // Start Repository Analysis
  const handleStartAnalysis = async () => {
    if (!repoUrl.trim()) return;
    setIsAnalyzing(true);
    setAnalysisError(null);
    setProgress({ status: 'starting', percentage: 2, message: 'Initiating analysis...' });

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo_url: repoUrl.trim(),
          branch: branch.trim() || null,
          github_token: githubToken.trim() || null,
          file_cap: parseInt(fileCap) || 40,
          use_cache: useCache
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Failed to start analysis');
      }

      const data = await res.json();
      setCurrentTaskId(data.task_id);
      pollProgress(data.task_id);
    } catch (e) {
      setIsAnalyzing(false);
      setAnalysisError(e.message);
    }
  };

  // Poll progress endpoint
  const pollProgress = (taskId) => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/progress/${taskId}`);
        if (!res.ok) return;

        const data = await res.json();
        setProgress(data);

        if (data.status === 'completed' && data.result) {
          clearInterval(interval);
          setAnalysisResult(data.result);
          setIsAnalyzing(false);
          if (data.result.explanations && data.result.explanations.length > 0) {
            setSelectedFilePath(data.result.explanations[0].file_path);
          }
          fetchCacheStats();
        } else if (data.status === 'failed') {
          clearInterval(interval);
          setIsAnalyzing(false);
          setAnalysisError(data.error || 'Analysis failed');
        }
      } catch (e) {
        console.error('Error polling progress:', e);
      }
    }, 600);
  };

  // Run PR Diff Simulation
  const handleSimulatePR = async () => {
    if (!prDiff.trim()) return;
    setIsSimulatingPR(true);
    try {
      const res = await fetch('/api/webhook/simulate-pr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo_url: prRepoUrl,
          pr_title: prTitle,
          pr_number: parseInt(prNumber) || 1,
          pr_diff: prDiff,
          post_comment: false
        })
      });
      const data = await res.json();
      setPrAnalysisResult(data);
    } catch (e) {
      alert('Error simulating PR: ' + e.message);
    } finally {
      setIsSimulatingPR(false);
    }
  };

  const selectedFile = useMemo(() => {
    if (!analysisResult || !selectedFilePath) return null;
    return analysisResult.explanations.find(f => f.file_path === selectedFilePath);
  }, [analysisResult, selectedFilePath]);

  const filteredFiles = useMemo(() => {
    if (!analysisResult) return [];
    return analysisResult.explanations.filter(f =>
      f.file_path.toLowerCase().includes(fileSearchQuery.toLowerCase())
    );
  }, [analysisResult, fileSearchQuery]);

  const filteredDocs = useMemo(() => {
    if (!analysisResult) return [];
    return analysisResult.api_docs.filter(doc => {
      const matchSearch = doc.name.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
                          doc.file_path.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
                          doc.purpose.toLowerCase().includes(docSearchQuery.toLowerCase());
      const matchType = docTypeFilter === 'all' || doc.type === docTypeFilter;
      return matchSearch && matchType;
    });
  }, [analysisResult, docSearchQuery, docTypeFilter]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Top Navigation Bar */}
      <header className="glass-header sticky top-0 z-50 px-6 py-3.5 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <span className="font-mono font-black text-white text-lg">S</span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                Schematic
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                IBM Granite AI
              </span>
            </div>
            <p className="text-xs text-slate-400">Repo-Wide Code Intelligence & Documentation</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          {[
            { id: 'analyze', label: 'Analyze', icon: '⚡' },
            { id: 'explanations', label: `Explanations ${analysisResult ? `(${analysisResult.total_files_analyzed})` : ''}`, icon: '💡' },
            { id: 'architecture', label: 'Architecture Diagram', icon: '🏗️' },
            { id: 'docs', label: `API Reference ${analysisResult ? `(${analysisResult.api_docs.length})` : ''}`, icon: '📚' },
            { id: 'pr', label: 'PR Webhook & Intelligence', icon: '🔀' },
            { id: 'settings', label: 'Settings', icon: '⚙️' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 flex items-center space-x-1.5 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>

        {/* Status Badge */}
        <div className="flex items-center space-x-3">
          {watsonxStatus && (
            <div
              onClick={() => setActiveTab('settings')}
              className={`cursor-pointer px-3 py-1 rounded-full text-xs font-medium flex items-center space-x-1.5 border transition-all ${
                watsonxStatus.configured
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30 hover:bg-amber-500/20'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${watsonxStatus.configured ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
              <span>{watsonxStatus.configured ? 'Granite 8B Connected' : 'Mock Mode (No Key)'}</span>
            </div>
          )}
          {cacheStats && (
            <div className="text-xs text-slate-400 bg-slate-900/80 px-2.5 py-1 rounded-lg border border-slate-800">
              ⚡ <span className="text-slate-200 font-semibold">{cacheStats.total_cached_files}</span> cached files
            </div>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6">
        {/* Banner when credentials are missing */}
        {watsonxStatus && !watsonxStatus.configured && activeTab !== 'settings' && (
          <div className="mb-6 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-sm">
            <div className="flex items-center space-x-3 text-amber-200">
              <span className="text-xl">⚠️</span>
              <div>
                <span className="font-semibold text-white">IBM watsonx.ai credentials not configured:</span>{' '}
                The prototype is running in intelligent Heuristic / Mock Mode. Set <code className="bg-amber-950/60 px-1.5 py-0.5 rounded text-amber-300 font-mono">WATSONX_API_KEY</code> and <code className="bg-amber-950/60 px-1.5 py-0.5 rounded text-amber-300 font-mono">WATSONX_PROJECT_ID</code> in <code className="font-mono">.env</code> to connect live Granite models.
              </div>
            </div>
            <button
              onClick={() => setActiveTab('settings')}
              className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs whitespace-nowrap"
            >
              Setup Credentials →
            </button>
          </div>
        )}

        {/* TAB 1: ANALYZE */}
        {activeTab === 'analyze' && (
          <div className="space-y-6">
            <div className="glass-card p-6 rounded-2xl shadow-xl space-y-5">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                  <span>⚡</span>
                  <span>Analyze Repository</span>
                </h2>
                <p className="text-sm text-slate-400">
                  Enter any public or private GitHub repository URL to trigger automated code explanation, architecture diagramming, and API reference documentation.
                </p>
              </div>

              {/* URL Input */}
              <div className="space-y-3">
                <div className="flex space-x-3">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                      </svg>
                    </div>
                    <input
                      type="text"
                      value={repoUrl}
                      onChange={(e) => setRepoUrl(e.target.value)}
                      placeholder="https://github.com/owner/repository"
                      className="w-full pl-11 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                    />
                  </div>
                  <button
                    onClick={handleStartAnalysis}
                    disabled={isAnalyzing || !repoUrl.trim()}
                    className={`px-6 py-3 rounded-xl font-semibold text-sm transition-all duration-150 flex items-center space-x-2 ${
                      isAnalyzing
                        ? 'bg-blue-800/50 text-blue-300 cursor-not-allowed'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/30'
                    }`}
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Analyzing Repo...</span>
                      </>
                    ) : (
                      <>
                        <span>🚀</span>
                        <span>Start Analysis</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Sample Repositories */}
                <div className="flex items-center space-x-2 text-xs text-slate-400 pt-1">
                  <span>Quick Demos:</span>
                  {[
                    { name: 'FastAPI (Python)', url: 'https://github.com/fastapi/fastapi' },
                    { name: 'Express.js (JavaScript)', url: 'https://github.com/expressjs/express' },
                    { name: 'Gin (Go)', url: 'https://github.com/gin-gonic/gin' },
                  ].map(s => (
                    <button
                      key={s.name}
                      onClick={() => setRepoUrl(s.url)}
                      className="px-2.5 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Advanced Settings Toggle */}
              <div>
                <button
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1"
                >
                  <span>{showAdvanced ? '▼' : '▶'}</span>
                  <span>Advanced Clone & Scope Options</span>
                </button>

                {showAdvanced && (
                  <div className="mt-3 p-4 rounded-xl bg-slate-900/70 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Branch or Tag (Optional):</label>
                      <input
                        type="text"
                        value={branch}
                        onChange={(e) => setBranch(e.target.value)}
                        placeholder="main / master"
                        className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">GitHub PAT (for private repos):</label>
                      <input
                        type="password"
                        value={githubToken}
                        onChange={(e) => setGithubToken(e.target.value)}
                        placeholder="ghp_xxxxxxxxxxxx"
                        className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">File Scope Cap (Current: {fileCap}):</label>
                      <input
                        type="range"
                        min="10"
                        max="100"
                        value={fileCap}
                        onChange={(e) => setFileCap(e.target.value)}
                        className="w-full accent-blue-500"
                      />
                    </div>
                    <div className="md:col-span-3 flex items-center space-x-2 pt-1">
                      <input
                        type="checkbox"
                        id="useCacheCheck"
                        checked={useCache}
                        onChange={(e) => setUseCache(e.target.checked)}
                        className="rounded bg-slate-800 border-slate-700 text-blue-600 focus:ring-0"
                      />
                      <label htmlFor="useCacheCheck" className="text-slate-300">
                        Enable SQLite File Caching (instant repeat analysis for unchanged files)
                      </label>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Live Progress Card */}
            {(isAnalyzing || progress) && (
              <div className="glass-card p-6 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg font-bold text-white">Analysis Status:</span>
                    <span className="text-xs px-2.5 py-1 rounded-full uppercase tracking-wider font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/30">
                      {progress ? progress.status : 'Processing'}
                    </span>
                  </div>
                  <span className="font-mono text-sm text-blue-400 font-bold">
                    {progress ? progress.percentage : 0}%
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-indigo-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${progress ? progress.percentage : 0}%` }}
                  ></div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                  <div className="truncate max-w-lg">
                    {progress?.message || 'Processing...'}
                  </div>
                  {progress && progress.total_files > 0 && (
                    <div className="flex items-center space-x-4">
                      <span>⚡ Hits: <b className="text-emerald-400">{progress.cache_hits}</b></span>
                      <span>🔄 Misses: <b className="text-blue-400">{progress.cache_misses}</b></span>
                      <span>Progress: <b className="text-slate-200">{progress.current_index}/{progress.total_files} files</b></span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Error Display */}
            {analysisError && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                <b>Error:</b> {analysisError}
              </div>
            )}

            {/* Analysis Summary Card */}
            {analysisResult && (
              <div className="glass-card p-6 rounded-2xl border border-emerald-500/20 space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                      <span className="text-emerald-400">✓</span>
                      <span>Analysis Completed: {analysisResult.repo_url}</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Analyzed in {analysisResult.duration_seconds}s using <b className="text-blue-400">{analysisResult.watsonx_model_used}</b>
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setActiveTab('explanations')}
                      className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs flex items-center space-x-1.5"
                    >
                      <span>Explore Code Explanations →</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('architecture')}
                      className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center space-x-1.5"
                    >
                      <span>View Architecture Diagram →</span>
                    </button>
                  </div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                    <div className="text-2xl font-bold text-white font-mono">{analysisResult.total_files_analyzed}</div>
                    <div className="text-xs text-slate-400 mt-1">Files Analyzed</div>
                    {analysisResult.is_capped && (
                      <span className="text-[10px] text-amber-400">Capped of {analysisResult.total_files_found}</span>
                    )}
                  </div>
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                    <div className="text-2xl font-bold text-emerald-400 font-mono">{analysisResult.cache_hits}</div>
                    <div className="text-xs text-slate-400 mt-1">⚡ Cache Hits</div>
                  </div>
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                    <div className="text-2xl font-bold text-blue-400 font-mono">{analysisResult.cache_misses}</div>
                    <div className="text-xs text-slate-400 mt-1">🔄 AI Generated</div>
                  </div>
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                    <div className="text-2xl font-bold text-indigo-400 font-mono">{analysisResult.architecture.subsystems.length}</div>
                    <div className="text-xs text-slate-400 mt-1">Subsystems</div>
                  </div>
                  <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                    <div className="text-2xl font-bold text-purple-400 font-mono">{analysisResult.api_docs.length}</div>
                    <div className="text-xs text-slate-400 mt-1">API Symbols</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CODE EXPLANATIONS */}
        {activeTab === 'explanations' && (
          <div>
            {!analysisResult ? (
              <div className="text-center py-20 text-slate-400 glass-card rounded-2xl">
                <div className="text-4xl mb-3">📁</div>
                <p className="font-semibold text-white">No repository analyzed yet.</p>
                <p className="text-xs mt-1">Go to the Analyze tab and run an analysis first.</p>
                <button
                  onClick={() => setActiveTab('analyze')}
                  className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-white text-xs font-medium"
                >
                  Go to Analyze →
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                {/* File Explorer List */}
                <div className="md:col-span-4 glass-card p-4 rounded-2xl space-y-3 max-h-[750px] flex flex-col">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-white text-sm">Repository Files ({analysisResult.explanations.length})</h3>
                    <span className="text-xs text-slate-500">{analysisResult.total_files_analyzed} of {analysisResult.total_files_found}</span>
                  </div>

                  <input
                    type="text"
                    value={fileSearchQuery}
                    onChange={(e) => setFileSearchQuery(e.target.value)}
                    placeholder="Search files..."
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />

                  <div className="flex-1 overflow-y-auto space-y-1 pr-1">
                    {filteredFiles.map(file => (
                      <button
                        key={file.file_path}
                        onClick={() => setSelectedFilePath(file.file_path)}
                        className={`w-full text-left p-2.5 rounded-xl text-xs transition flex items-center justify-between ${
                          selectedFilePath === file.file_path
                            ? 'bg-blue-600/20 text-white border border-blue-500/40 shadow-sm'
                            : 'hover:bg-slate-900 text-slate-300 border border-transparent'
                        }`}
                      >
                        <div className="truncate flex-1 pr-2">
                          <span className="font-mono">{file.file_path}</span>
                        </div>
                        <div className="flex items-center space-x-1.5 flex-shrink-0">
                          {file.cache_hit && (
                            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/20">
                              ⚡
                            </span>
                          )}
                          <span className="text-[10px] text-slate-500 font-mono">{file.line_count}L</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Detailed File Explanation Card */}
                <div className="md:col-span-8 space-y-4">
                  {selectedFile ? (
                    <div className="glass-card p-6 rounded-2xl space-y-6">
                      {/* Header */}
                      <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xl font-bold text-white font-mono">{selectedFile.file_path}</span>
                            {selectedFile.cache_hit && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                ⚡ Cache Hit
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-400 mt-1 font-mono">
                            Language: <span className="text-slate-200 uppercase">{selectedFile.language}</span> • Lines: <span className="text-slate-200">{selectedFile.line_count}</span> • Hash: <span className="text-slate-500">{selectedFile.content_hash.slice(0, 10)}...</span>
                          </p>
                        </div>
                      </div>

                      {/* Section 1: Overview */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center space-x-1.5">
                          <span>📋</span>
                          <span>Overview</span>
                        </h4>
                        <p className="text-sm text-slate-200 leading-relaxed bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80">
                          {selectedFile.overview}
                        </p>
                      </div>

                      {/* Section 2: Key Components */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center space-x-1.5">
                          <span>🧩</span>
                          <span>Key Components</span>
                        </h4>
                        <ul className="space-y-1.5">
                          {selectedFile.key_components.map((comp, idx) => (
                            <li key={idx} className="text-xs text-slate-300 bg-slate-900/40 p-2.5 rounded-lg border border-slate-800 flex items-start space-x-2">
                              <span className="text-indigo-400">•</span>
                              <span>{comp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Section 3: Execution Flow */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                          <span>🔄</span>
                          <span>Execution Flow</span>
                        </h4>
                        <p className="text-xs text-slate-300 bg-slate-900/60 p-3 rounded-xl border border-slate-800 leading-relaxed">
                          {selectedFile.flow}
                        </p>
                      </div>

                      {/* Section 4: Notable Risks */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                          <span>⚠️</span>
                          <span>Notable Risks & Architectural Considerations</span>
                        </h4>
                        <div className="text-xs text-amber-200/90 bg-amber-500/10 p-3 rounded-xl border border-amber-500/20 leading-relaxed">
                          {selectedFile.notable_risks}
                        </div>
                      </div>

                      {/* Section 5: Source Code Snippet */}
                      {selectedFile.raw_source && (
                        <div className="space-y-2 pt-2 border-t border-slate-800">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                            <span>💻</span>
                            <span>Source Code Preview</span>
                          </h4>
                          <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto text-[11px] font-mono text-slate-300 max-h-60">
                            <code>{selectedFile.raw_source}</code>
                          </pre>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="glass-card p-12 rounded-2xl text-center text-slate-400">
                      Select a file from the explorer to view its plain-language AI explanation.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ARCHITECTURE DIAGRAM */}
        {activeTab === 'architecture' && (
          <ArchitectureView analysisResult={analysisResult} />
        )}

        {/* TAB 4: AGGREGATED API REFERENCE DOCS */}
        {activeTab === 'docs' && (
          <div className="space-y-6">
            {!analysisResult ? (
              <div className="text-center py-20 text-slate-400 glass-card rounded-2xl">
                <div className="text-4xl mb-3">📚</div>
                <p className="font-semibold text-white">No API documentation available.</p>
                <p className="text-xs mt-1">Run a repository analysis to aggregate all public functions, classes, and routes.</p>
              </div>
            ) : (
              <div className="glass-card p-6 rounded-2xl space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                      <span>📚</span>
                      <span>Aggregated API Reference Documentation</span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      Discovered {analysisResult.api_docs.length} public functions, classes, and HTTP route handlers across the repository.
                    </p>
                  </div>

                  {/* Search and Filters */}
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={docSearchQuery}
                      onChange={(e) => setDocSearchQuery(e.target.value)}
                      placeholder="Search symbols, routes, or files..."
                      className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500 w-60"
                    />
                    <select
                      value={docTypeFilter}
                      onChange={(e) => setDocTypeFilter(e.target.value)}
                      className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-300 focus:outline-none"
                    >
                      <option value="all">All Types</option>
                      <option value="function">Functions</option>
                      <option value="route">HTTP Routes</option>
                      <option value="class">Classes</option>
                      <option value="method">Methods</option>
                    </select>
                  </div>
                </div>

                {/* API Docs Table & Cards */}
                <div className="space-y-4">
                  {filteredDocs.length === 0 ? (
                    <div className="text-center py-12 text-slate-500 text-xs">
                      No symbols match the current search filters.
                    </div>
                  ) : (
                    filteredDocs.map((doc, idx) => (
                      <div key={idx} className="p-4 bg-slate-900/70 border border-slate-800 rounded-xl space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                doc.type === 'route'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : doc.type === 'class'
                                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                                  : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              }`}>
                                {doc.type}
                              </span>
                              <span className="font-mono font-bold text-white text-sm">{doc.name}</span>
                            </div>
                            <p className="text-xs text-slate-400 mt-1 font-mono">
                              File: <span className="text-slate-300">{doc.file_path}</span> {doc.line_number && `(Line ${doc.line_number})`}
                            </p>
                          </div>
                        </div>

                        {/* Signature */}
                        <div className="p-2.5 bg-slate-950 rounded-lg font-mono text-xs text-blue-300 overflow-x-auto border border-slate-800/80">
                          {doc.signature}
                        </div>

                        {/* Purpose */}
                        <p className="text-xs text-slate-200">
                          <b>Purpose:</b> {doc.purpose}
                        </p>

                        {/* Parameters */}
                        {doc.parameters && doc.parameters.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Parameters:</span>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {doc.parameters.map((p, pIdx) => (
                                <div key={pIdx} className="p-2 bg-slate-950/60 rounded border border-slate-800/60 text-xs">
                                  <span className="font-mono text-indigo-300 font-bold">{p.name}</span>
                                  {p.type && <span className="text-slate-500 font-mono text-[11px]"> ({p.type})</span>}
                                  {p.default && <span className="text-slate-500 font-mono text-[11px]"> = {p.default}</span>}
                                  {p.required && <span className="text-amber-400 text-[10px] ml-1">*req</span>}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Returns & Errors */}
                        <div className="flex flex-wrap gap-4 text-xs pt-1 border-t border-slate-800/60 text-slate-400">
                          {doc.returns && (
                            <div>
                              <span className="text-slate-500">Returns:</span> <span className="text-slate-300 font-mono">{doc.returns}</span>
                            </div>
                          )}
                          {doc.errors && doc.errors.length > 0 && (
                            <div>
                              <span className="text-amber-500/80">Errors:</span> <span className="text-amber-300 font-mono">{doc.errors.join(', ')}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 5: PR WEBHOOK & INTELLIGENCE */}
        {activeTab === 'pr' && (
          <div className="space-y-6">
            {/* Webhook Instructions */}
            <div className="glass-card p-6 rounded-2xl border border-slate-800 space-y-4">
              <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                <span>🔀</span>
                <span>GitHub Pull Request Integration & Webhook</span>
              </h2>
              <p className="text-sm text-slate-300">
                Schematic can listen to GitHub Pull Request events (<code className="bg-slate-900 px-1 py-0.5 rounded font-mono text-blue-400">pull_request: opened, synchronize</code>), diff changed files against the cache, and automatically post review comments assessing functional changes, architecture staleness, and API doc updates.
              </p>

              <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Webhook Payload URL:</span>
                  <span className="text-emerald-400 font-semibold">POST /api/webhook/github</span>
                </div>
                <div className="text-slate-300 bg-slate-950 p-2.5 rounded border border-slate-800">
                  http://&lt;your-server-domain&gt;/api/webhook/github
                </div>
                <div className="text-slate-400 pt-1">
                  Content-Type: <b className="text-slate-200">application/json</b> • Secret: <b className="text-slate-200">Optional (matches GITHUB_WEBHOOK_SECRET)</b>
                </div>
              </div>
            </div>

            {/* Interactive PR Diff Simulator */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Simulator Form */}
              <div className="md:col-span-6 glass-card p-6 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-white text-sm flex items-center space-x-2">
                    <span>🧪</span>
                    <span>Interactive PR Diff Simulator</span>
                  </h3>
                  <span className="text-xs text-blue-400">Test PR Analysis</span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Target Repository URL:</label>
                    <input
                      type="text"
                      value={prRepoUrl}
                      onChange={(e) => setPrRepoUrl(e.target.value)}
                      className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <label className="block text-slate-400 mb-1">PR Title:</label>
                      <input
                        type="text"
                        value={prTitle}
                        onChange={(e) => setPrTitle(e.target.value)}
                        className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">PR #:</label>
                      <input
                        type="number"
                        value={prNumber}
                        onChange={(e) => setPrNumber(e.target.value)}
                        className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Unified Git Diff:</label>
                    <textarea
                      rows={10}
                      value={prDiff}
                      onChange={(e) => setPrDiff(e.target.value)}
                      placeholder="Paste git diff here..."
                      className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                    ></textarea>
                  </div>

                  <button
                    onClick={handleSimulatePR}
                    disabled={isSimulatingPR || !prDiff.trim()}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold text-xs transition flex items-center justify-center space-x-2"
                  >
                    {isSimulatingPR ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Evaluating Diff with Granite AI...</span>
                      </>
                    ) : (
                      <>
                        <span>⚡</span>
                        <span>Analyze PR Diff & Generate Automated Review Comment</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Simulated Output / Review Comment Preview */}
              <div className="md:col-span-6 glass-card p-6 rounded-2xl space-y-4">
                <h3 className="font-bold text-white text-sm flex items-center space-x-2">
                  <span>💬</span>
                  <span>Automated PR Comment Preview</span>
                </h3>

                {prAnalysisResult ? (
                  <div className="space-y-4">
                    {/* Status Badges */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className={`p-3 rounded-xl border text-xs ${
                        prAnalysisResult.needs_diagram_update
                          ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                          : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      }`}>
                        <div className="font-bold">Architecture Diagram</div>
                        <div>{prAnalysisResult.needs_diagram_update ? '⚠️ Needs Re-render' : '✅ Up to Date'}</div>
                      </div>
                      <div className={`p-3 rounded-xl border text-xs ${
                        prAnalysisResult.needs_docs_update
                          ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                          : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      }`}>
                        <div className="font-bold">API Documentation</div>
                        <div>{prAnalysisResult.needs_docs_update ? '⚠️ Needs Docs Update' : '✅ Up to Date'}</div>
                      </div>
                    </div>

                    {/* Markdown Comment Display */}
                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-3 font-sans">
                      <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed">
                        {prAnalysisResult.comment_markdown}
                      </pre>
                    </div>

                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(prAnalysisResult.comment_markdown);
                        alert('PR Comment copied to clipboard!');
                      }}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium border border-slate-700"
                    >
                      📋 Copy Markdown Comment
                    </button>
                  </div>
                ) : (
                  <div className="text-center py-20 text-slate-500 text-xs">
                    Click "Analyze PR Diff" on the left to simulate the automated GitHub PR bot comment.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: SETTINGS & WATSONX CONFIG */}
        {activeTab === 'settings' && (
          <SettingsView
            watsonxStatus={watsonxStatus}
            cacheStats={cacheStats}
            onRefresh={fetchWatsonxStatus}
            onClearCache={async () => {
              await fetch('/api/cache/clear', { method: 'POST' });
              fetchCacheStats();
              alert('Cache cleared!');
            }}
          />
        )}
      </main>
    </div>
  );
}

// Architecture Diagram Subcomponent
function ArchitectureView({ analysisResult }) {
  const [viewRaw, setViewRaw] = useState(false);
  const [renderError, setRenderError] = useState(null);
  const mermaidRef = useRef(null);

  useEffect(() => {
    if (!analysisResult || viewRaw) return;

    const renderMermaid = async () => {
      try {
        setRenderError(null);
        if (window.mermaid && mermaidRef.current) {
          mermaidRef.current.innerHTML = '';
          const id = `mermaid_svg_${Date.now()}`;
          const { svg } = await mermaid.render(id, analysisResult.architecture.raw_mermaid);
          if (mermaidRef.current) {
            mermaidRef.current.innerHTML = svg;
          }
        }
      } catch (e) {
        console.error('Mermaid render error:', e);
        setRenderError(e.message || 'Syntax error in generated Mermaid diagram');
      }
    };

    renderMermaid();
  }, [analysisResult, viewRaw]);

  if (!analysisResult) {
    return (
      <div className="text-center py-20 text-slate-400 glass-card rounded-2xl">
        <div className="text-4xl mb-3">🏗️</div>
        <p className="font-semibold text-white">No architecture diagram generated yet.</p>
        <p className="text-xs mt-1">Run a repository analysis to build the dependency graph and diagram.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="glass-card p-6 rounded-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <span>🏗️</span>
              <span>Repository Architecture & Dependency Graph</span>
            </h2>
            <p className="text-xs text-slate-400">
              Auto-clustered into {analysisResult.architecture.subsystems.length} subsystems across {analysisResult.architecture.total_modules} modules with {analysisResult.architecture.total_dependencies} internal dependency edges.
            </p>
          </div>

          <div className="flex space-x-2">
            <button
              onClick={() => setViewRaw(!viewRaw)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 transition"
            >
              {viewRaw ? '🖼️ View Rendered Diagram' : '📝 View Raw Mermaid Source'}
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(analysisResult.architecture.raw_mermaid);
                alert('Mermaid syntax copied to clipboard!');
              }}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium transition"
            >
              📋 Copy Mermaid Code
            </button>
          </div>
        </div>

        {/* Render Error Alert */}
        {renderError && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-center justify-between">
            <span>⚠️ Diagram rendering fallback: Displaying raw Mermaid code due to complex node nesting.</span>
            <button onClick={() => setViewRaw(true)} className="underline font-bold">View Source</button>
          </div>
        )}

        {/* Diagram Area */}
        {viewRaw || renderError ? (
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <pre className="text-xs font-mono text-blue-300 overflow-x-auto whitespace-pre-wrap">
              <code>{analysisResult.architecture.raw_mermaid}</code>
            </pre>
          </div>
        ) : (
          <div className="mermaid-container rounded-xl border border-slate-800 min-h-[450px] shadow-inner">
            <div ref={mermaidRef} className="mermaid flex justify-center items-center w-full"></div>
          </div>
        )}
      </div>

      {/* Subsystem Clusters Cards */}
      <div className="glass-card p-6 rounded-2xl space-y-4">
        <h3 className="font-bold text-white text-sm">Detected Subsystems & Module Clusters</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {analysisResult.architecture.subsystems.map((sub, idx) => (
            <div key={idx} className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{sub.name}</span>
                <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-mono font-semibold">
                  {sub.files.length} files
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{sub.description}</p>
              <div className="pt-2 border-t border-slate-800/60 max-h-36 overflow-y-auto space-y-1">
                {sub.files.map((f, fIdx) => (
                  <div key={fIdx} className="text-[11px] font-mono text-slate-300 truncate">
                    • {f}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Settings Subcomponent
function SettingsView({ watsonxStatus, cacheStats, onRefresh, onClearCache }) {
  const [testKey, setTestKey] = useState('');
  const [testProjectId, setTestProjectId] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/config/test-watsonx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          api_key: testKey.trim() || null,
          project_id: testProjectId.trim() || null
        })
      });
      const data = await res.json();
      setTestResult(data);
      if (data.success) {
        onRefresh();
      }
    } catch (e) {
      setTestResult({ success: false, message: e.message });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* IBM watsonx Status Card */}
      <div className="glass-card p-6 rounded-2xl space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center space-x-2">
          <span>⚙️</span>
          <span>IBM watsonx.ai Granite AI Engine</span>
        </h2>
        <p className="text-sm text-slate-300">
          Schematic uses IBM's foundation models via the watsonx REST API with automatic IAM token exchange, exponential backoff, and model fallback.
        </p>

        {watsonxStatus && (
          <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-slate-400">Status:</span>{' '}
                <b className={watsonxStatus.configured ? 'text-emerald-400' : 'text-amber-400'}>
                  {watsonxStatus.configured ? '✓ Configured & Ready' : '⚠️ Credentials Missing (Mock Mode Active)'}
                </b>
              </div>
              <div>
                <span className="text-slate-400">Target Region URL:</span>{' '}
                <span className="font-mono text-slate-200">{watsonxStatus.url}</span>
              </div>
              <div>
                <span className="text-slate-400">Primary Model:</span>{' '}
                <span className="font-mono text-blue-400 font-semibold">{watsonxStatus.model_id}</span>
              </div>
              <div>
                <span className="text-slate-400">Fallback Model:</span>{' '}
                <span className="font-mono text-slate-300">{watsonxStatus.fallback_model_id}</span>
              </div>
            </div>
            <div className="text-slate-400 pt-2 border-t border-slate-800">
              {watsonxStatus.message}
            </div>
          </div>
        )}
      </div>

      {/* Connection Test Tool */}
      <div className="glass-card p-6 rounded-2xl space-y-4">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <span>🔑</span>
          <span>Test IBM Cloud IAM & Granite Connection</span>
        </h3>
        <p className="text-xs text-slate-400">
          Optionally test custom credentials on the fly without restarting the server.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">WATSONX_API_KEY:</label>
            <input
              type="password"
              value={testKey}
              onChange={(e) => setTestKey(e.target.value)}
              placeholder="IBM Cloud IAM API Key"
              className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">WATSONX_PROJECT_ID:</label>
            <input
              type="text"
              value={testProjectId}
              onChange={(e) => setTestProjectId(e.target.value)}
              placeholder="watsonx Project ID (UUID)"
              className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs"
            />
          </div>
        </div>

        <button
          onClick={handleTestConnection}
          disabled={isTesting}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition"
        >
          {isTesting ? 'Testing Connection...' : '⚡ Test IBM IAM & Model Availability'}
        </button>

        {testResult && (
          <div className={`p-3 rounded-xl border text-xs ${
            testResult.success
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border-red-500/30 text-red-300'
          }`}>
            <b>{testResult.success ? 'Success:' : 'Error:'}</b> {testResult.message}
          </div>
        )}
      </div>

      {/* Cache Management Card */}
      <div className="glass-card p-6 rounded-2xl space-y-4">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <span>⚡</span>
          <span>SQLite Analysis Cache</span>
        </h3>
        {cacheStats && (
          <div className="text-xs text-slate-300 space-y-2">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="font-bold text-white text-lg font-mono">{cacheStats.total_cached_files}</div>
                <div className="text-slate-500 text-[10px]">Cached Files</div>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="font-bold text-white text-lg font-mono">{cacheStats.total_cached_repos}</div>
                <div className="text-slate-500 text-[10px]">Cached Repos</div>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="font-bold text-white text-lg font-mono">{(cacheStats.db_size_bytes / 1024).toFixed(1)} KB</div>
                <div className="text-slate-500 text-[10px]">Database Size</div>
              </div>
            </div>
            <div className="pt-2 flex justify-end">
              <button
                onClick={onClearCache}
                className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 rounded-lg text-xs font-semibold transition"
              >
                🗑️ Clear Analysis Cache
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Mount React App
const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<App />);
}
