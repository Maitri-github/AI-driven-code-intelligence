import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app

@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.get("/api/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "healthy"
        assert data["app"] == "Schematic"


@pytest.mark.asyncio
async def test_config_status_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.get("/api/config/status")
        assert resp.status_code == 200
        data = resp.json()
        assert "model_id" in data
        assert "ibm/granite-8b-code-instruct" in data["model_id"]


@pytest.mark.asyncio
async def test_cache_stats_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.get("/api/cache/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert "total_cached_files" in data


@pytest.mark.asyncio
async def test_simulate_pr_endpoint():
    payload = {
        "repo_url": "https://github.com/example/repo",
        "pr_title": "Fix memory leak in parser",
        "pr_number": 99,
        "pr_diff": "diff --git a/parser.py b/parser.py\n-def parse():\n+def parse(max_bytes=1000):"
    }
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.post("/api/webhook/simulate-pr", json=payload)
        assert resp.status_code == 200
        data = resp.json()
        assert "comment_markdown" in data
        assert "#99" in data["comment_markdown"]
