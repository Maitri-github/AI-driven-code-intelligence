import pytest
from app.services.code_parser import code_parser
from app.services.architecture import architecture_service

def test_architecture_clustering_and_mermaid():
    file1 = code_parser.parse_file("app/main.py", "from app.routes.api import router\napp = FastAPI()")
    file2 = code_parser.parse_file("app/routes/api.py", "from app.services.engine import run_job\n@router.get('/job')\ndef get_job(): pass")
    file3 = code_parser.parse_file("app/services/engine.py", "from app.models.data import DataRecord\ndef run_job(): pass")
    file4 = code_parser.parse_file("app/models/data.py", "class DataRecord: pass")
    file5 = code_parser.parse_file("app/utils/helpers.py", "def format_date(): pass")

    parsed_files = [file1, file2, file3, file4, file5]
    arch_result = architecture_service.build_architecture(parsed_files)

    assert arch_result.total_modules == 5
    assert len(arch_result.subsystems) >= 3
    assert "graph TD" in arch_result.mermaid_diagram
    assert "subgraph" in arch_result.mermaid_diagram
    
    # Check that node styling classes are defined
    assert "classDef" in arch_result.mermaid_diagram
    assert len(arch_result.dependencies) > 0
