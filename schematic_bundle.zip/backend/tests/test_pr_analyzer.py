import pytest
from app.services.pr_analyzer import pr_analyzer

@pytest.mark.asyncio
async def test_pr_diff_changed_files_extraction():
    diff = """
diff --git a/app/services/auth.py b/app/services/auth.py
index 1234567..89abcdef 100644
--- a/app/services/auth.py
+++ b/app/services/auth.py
@@ -10,4 +10,6 @@ def verify_token(token: str):
+def generate_refresh_token(user_id: int):
+    return "token"
diff --git a/app/config.py b/app/config.py
--- a/app/config.py
+++ b/app/config.py
@@ -1,3 +1,4 @@
+JWT_SECRET = "secret"
"""
    files = pr_analyzer.extract_changed_files_from_diff(diff)
    assert "app/services/auth.py" in files
    assert "app/config.py" in files
    assert len(files) == 2


@pytest.mark.asyncio
async def test_pr_diff_impact_analysis():
    diff = """
diff --git a/app/routes/api.py b/app/routes/api.py
--- a/app/routes/api.py
+++ b/app/routes/api.py
@@ -1,5 +1,6 @@
+from app.services.billing import process_payment
-def get_data():
+def get_data(user_id: int):
"""
    result = await pr_analyzer.analyze_pr_diff(
        repo_url="https://github.com/example/repo",
        pr_diff=diff,
        pr_title="Add billing integration",
        pr_number=42
    )

    assert result.needs_diagram_update is True  # new import added
    assert result.needs_docs_update is True     # signature changed
    assert "Schematic Code Intelligence" in result.comment_markdown
    assert "#42" in result.comment_markdown
