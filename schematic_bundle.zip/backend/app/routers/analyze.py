import uuid
import asyncio
import logging
from fastapi import APIRouter, HTTPException, BackgroundTasks
from app.models.schemas import (
    RepoAnalyzeRequest,
    RepoAnalysisResult,
    AnalysisProgress
)
from app.services.analyzer import repo_analyzer, active_tasks
from app.services.cache import cache_service

from typing import Dict, Any

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["Analysis"])


async def run_analysis_task(task_id: str, request: RepoAnalyzeRequest):
    try:
        await repo_analyzer.analyze_repository(request, task_id=task_id)
    except Exception as e:
        logger.error(f"Analysis task {task_id} failed: {e}", exc_info=True)
        if task_id in active_tasks:
            active_tasks[task_id].status = "failed"
            active_tasks[task_id].error = str(e)
            active_tasks[task_id].message = f"Analysis error: {str(e)}"


@router.post("/analyze", response_model=Dict[str, Any])
async def start_analysis(request: RepoAnalyzeRequest, background_tasks: BackgroundTasks):
    """Trigger repository code intelligence analysis."""
    task_id = str(uuid.uuid4())
    progress = AnalysisProgress(
        task_id=task_id,
        repo_url=request.repo_url,
        status="pending",
        message="Queuing repository analysis...",
        percentage=0
    )
    active_tasks[task_id] = progress
    background_tasks.add_task(run_analysis_task, task_id, request)

    return {
        "task_id": task_id,
        "repo_url": request.repo_url,
        "status": "pending",
        "message": "Analysis started successfully."
    }


@router.get("/progress/{task_id}", response_model=AnalysisProgress)
async def get_progress(task_id: str):
    """Poll live progress for an active or completed analysis task."""
    if task_id in active_tasks:
        return active_tasks[task_id]

    # Check if results exist in SQLite
    cached_result = cache_service.get_repo_results(task_id)
    if cached_result:
        result_obj = RepoAnalysisResult(**cached_result)
        return AnalysisProgress(
            task_id=task_id,
            repo_url=result_obj.repo_url,
            status="completed",
            percentage=100,
            message="Analysis completed.",
            result=result_obj
        )

    raise HTTPException(status_code=404, detail="Analysis task not found.")


@router.get("/results/{repo_id}", response_model=RepoAnalysisResult)
async def get_results(repo_id: str):
    """Retrieve full analysis results by task/repo ID."""
    if repo_id in active_tasks and active_tasks[repo_id].result:
        return active_tasks[repo_id].result

    cached_result = cache_service.get_repo_results(repo_id)
    if cached_result:
        return RepoAnalysisResult(**cached_result)

    raise HTTPException(status_code=404, detail="Results not found.")
