import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Header, Request, HTTPException, BackgroundTasks
import httpx
from app.models.schemas import PRDiffSimulateRequest, PRAnalysisResponse
from app.services.pr_analyzer import pr_analyzer
from app.config import settings

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/webhook", tags=["PR Webhook"])

# In-memory log of recent webhook events for UI display
webhook_event_logs: List[Dict[str, Any]] = []


async def process_github_pr_event(payload: Dict[str, Any]):
    action = payload.get("action")
    pr_data = payload.get("pull_request", {})
    repo_data = payload.get("repository", {})

    if action not in ("opened", "synchronize", "reopened"):
        logger.info(f"Ignoring unsupported PR action: {action}")
        return

    pr_number = pr_data.get("number")
    pr_title = pr_data.get("title", f"PR #{pr_number}")
    diff_url = pr_data.get("diff_url")
    html_url = pr_data.get("html_url")
    repo_url = repo_data.get("html_url")

    # Fetch diff text from GitHub
    diff_text = ""
    if diff_url:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                headers = {"User-Agent": "Schematic-App"}
                resp = await client.get(diff_url, headers=headers)
                if resp.status_code == 200:
                    diff_text = resp.text
        except Exception as e:
            logger.warning(f"Failed to fetch PR diff from {diff_url}: {e}")

    if not diff_text:
        diff_text = f"PR #{pr_number}: {pr_title}\nModified files across base/head branch."

    # Run PR analysis
    analysis_res = await pr_analyzer.analyze_pr_diff(
        repo_url=repo_url or html_url,
        pr_diff=diff_text,
        pr_title=pr_title,
        pr_number=pr_number,
        post_comment=False
    )

    event_record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "pull_request",
        "action": action,
        "repo": repo_data.get("full_name", repo_url),
        "pr_number": pr_number,
        "pr_title": pr_title,
        "pr_url": html_url,
        "analysis": analysis_res.model_dump()
    }
    webhook_event_logs.insert(0, event_record)
    if len(webhook_event_logs) > 50:
        webhook_event_logs.pop()


@router.post("/github")
async def github_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_github_event: Optional[str] = Header(None)
):
    """Receive live GitHub Webhook events for pull requests."""
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload.")

    event_type = x_github_event or payload.get("event", "unknown")
    logger.info(f"Received GitHub webhook event: {event_type}")

    if event_type == "pull_request":
        background_tasks.add_task(process_github_pr_event, payload)
        return {
            "status": "processing",
            "event": event_type,
            "action": payload.get("action"),
            "message": "PR webhook queued for code intelligence analysis."
        }

    return {"status": "ignored", "event": event_type, "message": "Event ignored."}


@router.post("/simulate-pr", response_model=PRAnalysisResponse)
async def simulate_pr_analysis(request: PRDiffSimulateRequest):
    """
    Interactively analyze any unified PR diff and generate
    the automated code intelligence review comment.
    """
    return await pr_analyzer.analyze_pr_diff(
        repo_url=request.repo_url,
        pr_diff=request.pr_diff,
        pr_title=request.pr_title,
        pr_number=request.pr_number,
        github_token=request.github_token,
        post_comment=request.post_comment
    )


@router.get("/events")
async def get_webhook_events():
    """Retrieve recent webhook event history."""
    return {"events": webhook_event_logs}
