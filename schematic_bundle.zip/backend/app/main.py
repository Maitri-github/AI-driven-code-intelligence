import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.config import settings, BASE_DIR
from app.routers import analyze, webhook, config, cache

app = FastAPI(
    title="Schematic — Repo-Wide Code Intelligence & Documentation Prototype",
    description="Automated repository intelligence, architecture diagramming, and API documentation powered by IBM watsonx.ai Granite models.",
    version="1.0.0"
)

# Enable CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(analyze.router)
app.include_router(webhook.router)
app.include_router(config.router)
app.include_router(cache.router)


@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "app": "Schematic",
        "watsonx_configured": settings.has_watsonx_credentials,
        "watsonx_model": settings.watsonx_model_id
    }


# Frontend static files directory
FRONTEND_DIR = BASE_DIR / "frontend"

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    async def serve_index():
        return FileResponse(FRONTEND_DIR / "index.html")

    # Catch-all route to serve SPA frontend
    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        file_path = FRONTEND_DIR / full_path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(FRONTEND_DIR / "index.html")
