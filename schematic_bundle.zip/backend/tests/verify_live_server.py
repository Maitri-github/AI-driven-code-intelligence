import sys
import time
import httpx

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

client = httpx.Client(base_url="http://localhost:8000", timeout=30.0)

# 1. Health
r = client.get("/api/health")
print("Health Check:", r.status_code, r.json())
assert r.status_code == 200

# 2. Config status
r = client.get("/api/config/status")
print("Config Status:", r.status_code, r.json())
assert r.status_code == 200

# 3. Cache stats
r = client.get("/api/cache/stats")
print("Cache Stats:", r.status_code, r.json())
assert r.status_code == 200

# 4. Simulate PR
pr_payload = {
    "repo_url": "https://github.com/fastapi/fastapi",
    "pr_title": "feat: Add profile route and auth module",
    "pr_number": 105,
    "pr_diff": """diff --git a/app/routes/profile.py b/app/routes/profile.py
new file mode 100644
--- /dev/null
+++ b/app/routes/profile.py
@@ -0,0 +1,10 @@
+from fastapi import APIRouter
+from app.services.auth import verify_token
+router = APIRouter()
+@router.get('/profile')
+def get_profile():
+    return {'status': 'ok'}
+"""
}
r = client.post("/api/webhook/simulate-pr", json=pr_payload)
print("Simulate PR:", r.status_code)
print("Generated Comment:")
print("-" * 50)
print(r.json()["comment_markdown"])
print("-" * 50)

print("\nALL LIVE SERVER TESTS PASSED SUCCESSFULLY!")
