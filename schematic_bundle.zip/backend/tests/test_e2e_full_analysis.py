import pytest
import tempfile
import zipfile
import io
from pathlib import Path
from unittest.mock import patch
from app.models.schemas import RepoAnalyzeRequest
from app.services.analyzer import repo_analyzer
from app.services.cache import cache_service

@pytest.mark.asyncio
async def test_full_analysis_and_caching_lifecycle():
    # Clear cache to guarantee pristine test state
    cache_service.clear()

    # Create a realistic sample repository directory
    with tempfile.TemporaryDirectory() as repo_dir:
        repo_path = Path(repo_dir)
        
        # main.py
        (repo_path / "main.py").write_text("""
from fastapi import FastAPI
from app.routes.items import router as items_router
from app.services.auth import init_auth

app = FastAPI(title="Sample App")
init_auth()
app.include_router(items_router)
""", encoding="utf-8")

        # app/routes/items.py
        (repo_path / "app" / "routes").mkdir(parents=True, exist_ok=True)
        (repo_path / "app" / "routes" / "items.py").write_text("""
from fastapi import APIRouter, HTTPException
from app.models.item import ItemSchema

router = APIRouter(prefix="/items")

@router.get("/{item_id}", response_model=ItemSchema)
async def get_item(item_id: int):
    \"\"\"Retrieve item by ID.\"\"\"
    if item_id <= 0:
        raise HTTPException(status_code=400, detail="Invalid ID")
    return {"id": item_id, "name": "Sample"}
""", encoding="utf-8")

        # app/services/auth.py
        (repo_path / "app" / "services").mkdir(parents=True, exist_ok=True)
        (repo_path / "app" / "services" / "auth.py").write_text("""
def init_auth():
    \"\"\"Initialize authentication system.\"\"\"
    print("Auth initialized")
""", encoding="utf-8")

        # app/models/item.py
        (repo_path / "app" / "models").mkdir(parents=True, exist_ok=True)
        (repo_path / "app" / "models" / "item.py").write_text("""
from pydantic import BaseModel

class ItemSchema(BaseModel):
    id: int
    name: str
""", encoding="utf-8")

        # Mock clone_or_download to copy our temp files into the clone destination
        def mock_clone(repo_url, target_dir, branch=None, github_token=None):
            import shutil
            for item in repo_path.iterdir():
                if item.is_dir():
                    shutil.copytree(item, target_dir / item.name, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, target_dir / item.name)
            return target_dir

        with patch("app.services.repo_cloner.RepoCloner.clone_or_download", side_effect=mock_clone):
            req = RepoAnalyzeRequest(
                repo_url="https://github.com/mock-org/sample-repo",
                file_cap=10,
                use_cache=True
            )

            # --- RUN 1: First Run (Cache Misses) ---
            result1 = await repo_analyzer.analyze_repository(req)

            assert result1.total_files_analyzed == 4
            assert result1.cache_hits == 0
            assert result1.cache_misses == 4
            assert len(result1.explanations) == 4
            assert len(result1.architecture.subsystems) >= 2
            assert "graph TD" in result1.architecture.mermaid_diagram
            assert len(result1.api_docs) >= 3

            # --- RUN 2: Second Run (Cache Hits) ---
            result2 = await repo_analyzer.analyze_repository(req)

            assert result2.total_files_analyzed == 4
            assert result2.cache_hits == 4
            assert result2.cache_misses == 0
            # Verify every explanation has cache_hit = True
            for exp in result2.explanations:
                assert exp.cache_hit is True
