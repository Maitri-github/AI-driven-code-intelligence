from fastapi import APIRouter
from app.models.schemas import CacheStatsResponse
from app.services.cache import cache_service

router = APIRouter(prefix="/api/cache", tags=["Cache Management"])


@router.get("/stats", response_model=CacheStatsResponse)
async def get_cache_stats():
    """Retrieve statistics about the SQLite analysis cache."""
    stats = cache_service.get_stats()
    return CacheStatsResponse(**stats)


@router.post("/clear")
async def clear_cache():
    """Clear all cached file hashes and repository results."""
    success = cache_service.clear()
    return {
        "success": bool(success),
        "message": "Cache successfully cleared." if success else "Failed to clear cache."
    }
